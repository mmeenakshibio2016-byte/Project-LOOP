PROJECT LOOP - SUBMISSION BUNDLE

1. Project-LOOP-Report.pdf - formatted project report with screenshots.
2. Project-LOOP-Demo-with-Sound.mp4 - app walkthrough with original music and subtle sound effects.
3. Project-LOOP-Feedback-Reflection-Guide.mp4 - captioned 44-second recording guide with a soft music bed and no speech. Record your own voice while following the captions before submitting the feedback video.
4. Project-LOOP-Feedback-Reflection-Script.txt - narration text.
5. Project-LOOP-Report.md - editable project report.
6. Screenshots/ - sample app captures.

Live public demo: https://temporary-snappy-drizzle-easpqly.vercel.app/
Public repository: https://github.com/mmeenakshibio2016-byte/Project-LOOP
