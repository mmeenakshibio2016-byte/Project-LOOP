PROJECT LOOP - SUBMISSION BUNDLE

1. Project-LOOP-Report.pdf - formatted report with demo screenshots and delivery/verification details.
2. Project-LOOP-Demo-with-Sound.mp4 - 28-second 1280x720 app walkthrough with original background music and subtle transition sound effects.
3. Project-LOOP-Report.md - editable Markdown copy of the report.
4. Screenshots/ - captures of the welcome page, dashboard, inbox, Q&A, ingestion, Voice of Customer report, viewer mode, and prioritization.

Live public demo: https://temporary-snappy-drizzle-easpqly.vercel.app/
Public repository: https://github.com/mmeenakshibio2016-byte/Project-LOOP

All app data and AI behavior are simulated/local demo content; see the report for scope and limitations.
